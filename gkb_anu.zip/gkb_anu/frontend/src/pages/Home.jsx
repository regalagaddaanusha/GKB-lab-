import React from 'react'

const Home=() =>{
    return(
        <div className='text-3xl text-blue-500'> Home </div>
    )
}

export default Home